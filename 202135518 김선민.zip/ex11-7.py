import turtle
t=turtle.Turtle()
t.shape('turtle')
for i in range(5):
  t.forward(300)
  t.left(144)
