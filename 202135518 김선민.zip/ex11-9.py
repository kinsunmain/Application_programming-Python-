import turtle
t=turtle.Turtle()
t.shape('turtle')
t.speed(0)
t.pencolor('red')
for x in range(36):
  t.circle(90)
  t.right(10)
