import turtle

t=turtle.Turtle()

t.forward(100)
t.left(360/3)
t.forward(100)
t.left(360/3)
t.forward(100)
t.left(360/3)


