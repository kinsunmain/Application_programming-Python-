from tkinter import *
window = Tk() 
b1 = Button(window, text='눌러주세요')
b1.pack()
window.mainloop()
