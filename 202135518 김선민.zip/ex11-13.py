from tkinter import *
window = Tk() 
l1 = Label(window, text='Label')
l1.pack() 
e1 = Entry(window)
e1.pack() 
b1 = Button(window, text='Button')
b1.pack()
window.mainloop() 
