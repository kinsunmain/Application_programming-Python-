import turtle
t=turtle.Turtle()
n=5
for i in range(n):
  t.forward(100)
  t.left(360/n)
